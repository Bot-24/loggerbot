# discord-log-bot-js
A test bot that creates a audit log in a discord server written in JavaScript. ((Work in progress))

I made a first version of this same bot using JDA (Java) and now I´m rewriting it using discord.js (JavaScript).

Made using discord.js: https://github.com/discordjs/discord.js


Note: The files don't include discord.js files neither node files.
